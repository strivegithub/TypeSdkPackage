package com.typesdk.demo;

import com.unity3d.player.*;

/**
 * @deprecated Use UnityPlayerNativeActivity instead.
 */
public class UnityPlayerActivity extends UnityPlayerNativeActivity { }